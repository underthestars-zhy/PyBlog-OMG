/**
 * ___  ____                _      _ 
 * |  \/  (_)              | |    | |
 * | .  . |_ _ __ __ _  ___| | ___| |
 * | |\/| | | '__/ _` |/ __| |/ _ \ |
 * | |  | | | | | (_| | (__| |  __/_|
 * \_|  |_/_|_|  \__,_|\___|_|\___(_)
 * 
 * Miracle-front.js
 * 前台脚本
 */

/* GoTop */

$('#gotop').hide();
$(window).scroll(function() {
    if ($(window).scrollTop() > 450) {
        miracle.scaleIn($('#gotop'), '0.7');
    } else {
        miracle.scaleOut($('#gotop'), '0.7');
    }
});
$(document).ready(function(){
    $("#gotop").on("click", miracle.GoTop);
});

/**
 * Libs
 */

/* 初始化第三方开源库 */
const notyf = new Notyf();
/* Miracle! */
miracle.linkTarget();
miracle.panguSpacing();
miracle.owoLoad();
miracle.highlight();
miracle.DarkListen();
miracle.NavToggleListen();
miracle.adminBtn();
miracle.searchBtn();
miracle.tocInit();

miracle.markCommentParent();
miracleComment.bindButton();
miracleComment.core();

/* pjax */

/**
 *  Load Pjax
 */
if (loadPjax) {
    $(document).pjax('a[href^="' + siteurl + '"]:not(a[target="_blank"], a[no-pjax], .comment-reply a, .cancel-comment-reply a)', {
        container: '#pjax-container',
        fragment: '#pjax-container',
        timeout: 8000
    }).on('pjax:send', function() {
        NProgress.start();
        miracle.GoTop();
        if ($('#toc').length) tocbot.destroy();//摧毁 toc
        //Others
        beforePjax();
    }).on('pjax:complete', function() {
        //NProgress
        NProgress.done();
		//Link
        miracle.linkTarget();
        //Pangu
        miracle.panguSpacing();
        //owo
        miracle.owoLoad();
        //highlight
        miracle.highlight();
        //gazeimg
        $('img[data-gisrc]:not([data-gi-init])').giLazy();
        //toc
        miracle.tocInit();
        //markComment
        miracle.markCommentParent();
        miracleComment.bindButton();
        miracleComment.core();
        //Others
        afterPjax();
    });
}